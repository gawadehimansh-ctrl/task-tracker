import { redirect } from 'next/navigation';
import { isAuthenticated } from '@/lib/auth';
import Dashboard from '@/components/Dashboard';

export default async function Home() {
  const authed = await isAuthenticated();
  if (!authed) {
    redirect('/login');
  }
  return <Dashboard />;
}
