import { NextRequest, NextResponse } from 'next/server';
import { getTasks, createTask, ensureSchema } from '@/lib/db';
import { isAuthenticated } from '@/lib/auth';

export async function GET() {
  const authed = await isAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const tasks = await getTasks();
    return NextResponse.json({ tasks });
  } catch {
    // table might not exist yet
    await ensureSchema();
    const tasks = await getTasks();
    return NextResponse.json({ tasks });
  }
}

export async function POST(req: NextRequest) {
  const authed = await isAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const body = await req.json();
  const { title, description, url, bucket, week_start, assignee } = body;
  if (!title || !bucket || !week_start) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }
  const task = await createTask({ title, description, url, bucket, week_start, assignee });
  return NextResponse.json({ task });
}
