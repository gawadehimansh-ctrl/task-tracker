import { NextResponse } from 'next/server';
import { ensureSchema } from '@/lib/db';
import { isAuthenticated } from '@/lib/auth';

export async function POST() {
  const authed = await isAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  await ensureSchema();
  return NextResponse.json({ success: true });
}
