import { NextRequest, NextResponse } from 'next/server';
import { checkPassword, createSession, clearSession, isAuthenticated } from '@/lib/auth';

export async function GET() {
  const authed = await isAuthenticated();
  return NextResponse.json({ authenticated: authed });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { password } = body;
  if (checkPassword(password)) {
    await createSession();
    return NextResponse.json({ success: true });
  }
  return NextResponse.json({ success: false, error: 'Incorrect password' }, { status: 401 });
}

export async function DELETE() {
  await clearSession();
  return NextResponse.json({ success: true });
}
