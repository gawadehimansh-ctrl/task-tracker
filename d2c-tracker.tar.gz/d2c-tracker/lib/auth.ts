import { cookies } from 'next/headers';
import crypto from 'crypto';

const COOKIE_NAME = 'd2c_session';

function getSecret() {
  return process.env.APP_PASSWORD || '';
}

function sign(value: string) {
  const secret = getSecret();
  return crypto.createHmac('sha256', secret).update(value).digest('hex');
}

export function checkPassword(input: string): boolean {
  const secret = getSecret();
  if (!secret) return false;
  return input === secret;
}

export async function createSession() {
  const token = sign('valid-session');
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 30, // 30 days
  });
}

export async function isAuthenticated(): Promise<boolean> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return false;
  return token === sign('valid-session');
}

export async function clearSession() {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}
