import { sql } from '@vercel/postgres';

export const BUCKETS = [
  'Meta',
  'Google',
  'Catalog and Pricing BAU',
  'CRO',
  'Offers/Sale',
  'Retention - WhatsApp',
  'Returns & Logistics',
  'P&L Margin Analysis',
] as const;

export type Bucket = (typeof BUCKETS)[number];

export type Task = {
  id: number;
  title: string;
  description: string | null;
  url: string | null;
  bucket: string;
  week_start: string; // ISO date string, Monday of that week
  status: 'pending' | 'done';
  assignee: string | null;
  created_at: string;
};

export async function ensureSchema() {
  await sql`
    CREATE TABLE IF NOT EXISTS tasks (
      id SERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      url TEXT,
      bucket TEXT NOT NULL,
      week_start DATE NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      assignee TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;
}

export async function getTasks(): Promise<Task[]> {
  const { rows } = await sql<Task>`
    SELECT id, title, description, url, bucket,
           to_char(week_start, 'YYYY-MM-DD') as week_start,
           status, assignee, created_at
    FROM tasks
    ORDER BY week_start DESC, bucket ASC, id ASC;
  `;
  return rows;
}

export async function createTask(data: {
  title: string;
  description?: string;
  url?: string;
  bucket: string;
  week_start: string;
  assignee?: string;
}): Promise<Task> {
  const { rows } = await sql<Task>`
    INSERT INTO tasks (title, description, url, bucket, week_start, assignee)
    VALUES (${data.title}, ${data.description || null}, ${data.url || null}, ${data.bucket}, ${data.week_start}, ${data.assignee || null})
    RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;
  `;
  return rows[0];
}

export async function updateTaskField(
  id: number,
  field: 'title' | 'description' | 'url' | 'bucket' | 'week_start' | 'status' | 'assignee',
  value: string
): Promise<Task> {
  let rows;
  switch (field) {
    case 'title':
      ({ rows } = await sql<Task>`UPDATE tasks SET title = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
    case 'description':
      ({ rows } = await sql<Task>`UPDATE tasks SET description = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
    case 'url':
      ({ rows } = await sql<Task>`UPDATE tasks SET url = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
    case 'bucket':
      ({ rows } = await sql<Task>`UPDATE tasks SET bucket = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
    case 'week_start':
      ({ rows } = await sql<Task>`UPDATE tasks SET week_start = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
    case 'status':
      ({ rows } = await sql<Task>`UPDATE tasks SET status = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
    case 'assignee':
      ({ rows } = await sql<Task>`UPDATE tasks SET assignee = ${value} WHERE id = ${id} RETURNING id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at;`);
      break;
  }
  return rows[0];
}

export async function updateTaskMany(
  id: number,
  data: {
    title?: string;
    description?: string;
    url?: string;
    bucket?: string;
    week_start?: string;
    status?: string;
    assignee?: string;
  }
): Promise<Task> {
  const fields = Object.keys(data) as Array<keyof typeof data>;
  let result: Task | null = null;
  for (const field of fields) {
    const value = data[field];
    if (value === undefined) continue;
    result = await updateTaskField(id, field, value);
  }
  if (!result) {
    const { rows } = await sql<Task>`SELECT id, title, description, url, bucket, to_char(week_start, 'YYYY-MM-DD') as week_start, status, assignee, created_at FROM tasks WHERE id = ${id};`;
    result = rows[0];
  }
  return result;
}

export async function deleteTask(id: number): Promise<void> {
  await sql`DELETE FROM tasks WHERE id = ${id};`;
}
