// Weeks run Monday -> Sunday. week_start is stored as the Monday's ISO date (YYYY-MM-DD).

export function getMonday(d: Date): Date {
  const date = new Date(d);
  const day = date.getDay(); // 0 = Sun, 1 = Mon, ...
  const diff = day === 0 ? -6 : 1 - day;
  date.setDate(date.getDate() + diff);
  date.setHours(0, 0, 0, 0);
  return date;
}

export function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function currentWeekStart(): string {
  return toISODate(getMonday(new Date()));
}

export function nextWeekStart(): string {
  const monday = getMonday(new Date());
  monday.setDate(monday.getDate() + 7);
  return toISODate(monday);
}

export function addWeeks(weekStartISO: string, n: number): string {
  const d = new Date(weekStartISO + 'T00:00:00');
  d.setDate(d.getDate() + n * 7);
  return toISODate(d);
}

export function formatWeekLabel(weekStartISO: string): string {
  const start = new Date(weekStartISO + 'T00:00:00');
  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  const opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' };
  const startStr = start.toLocaleDateString('en-GB', opts);
  const endStr = end.toLocaleDateString('en-GB', opts);
  return `${startStr} – ${endStr}`;
}
