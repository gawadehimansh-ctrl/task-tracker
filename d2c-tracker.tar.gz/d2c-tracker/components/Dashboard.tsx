'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { BUCKETS } from '@/lib/db';
import {
  currentWeekStart,
  nextWeekStart,
  addWeeks,
  formatWeekLabel,
} from '@/lib/weeks';
import TaskModal from './TaskModal';

export type Task = {
  id: number;
  title: string;
  description: string | null;
  url: string | null;
  bucket: string;
  week_start: string;
  status: 'pending' | 'done';
  assignee: string | null;
  created_at: string;
};

export default function Dashboard() {
  const router = useRouter();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWeek, setSelectedWeek] = useState<string>(nextWeekStart());
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [prefillBucket, setPrefillBucket] = useState<string>(BUCKETS[0]);
  const [bucketFilter, setBucketFilter] = useState<string>('all');

  const loadTasks = useCallback(async () => {
    setLoading(true);
    const res = await fetch('/api/tasks');
    if (res.status === 401) {
      router.push('/login');
      return;
    }
    const data = await res.json();
    setTasks(data.tasks || []);
    setLoading(false);
  }, [router]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const weekOptions = useMemo(() => {
    const cur = currentWeekStart();
    const opts: string[] = [];
    for (let i = -8; i <= 4; i++) {
      opts.push(addWeeks(cur, i));
    }
    return opts;
  }, []);

  const weekTasks = useMemo(
    () => tasks.filter((t) => t.week_start === selectedWeek),
    [tasks, selectedWeek]
  );

  const filteredTasks = useMemo(
    () =>
      bucketFilter === 'all'
        ? weekTasks
        : weekTasks.filter((t) => t.bucket === bucketFilter),
    [weekTasks, bucketFilter]
  );

  const tasksByBucket = useMemo(() => {
    const map: Record<string, Task[]> = {};
    for (const b of BUCKETS) map[b] = [];
    for (const t of filteredTasks) {
      if (!map[t.bucket]) map[t.bucket] = [];
      map[t.bucket].push(t);
    }
    return map;
  }, [filteredTasks]);

  const weekProgress = useMemo(() => {
    if (weekTasks.length === 0) return 0;
    const done = weekTasks.filter((t) => t.status === 'done').length;
    return Math.round((done / weekTasks.length) * 100);
  }, [weekTasks]);

  async function toggleStatus(task: Task) {
    const newStatus = task.status === 'done' ? 'pending' : 'done';
    setTasks((prev) =>
      prev.map((t) => (t.id === task.id ? { ...t, status: newStatus } : t))
    );
    await fetch(`/api/tasks/${task.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus }),
    });
  }

  async function deleteTask(id: number) {
    if (!confirm('Delete this task?')) return;
    setTasks((prev) => prev.filter((t) => t.id !== id));
    await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
  }

  function openAddModal(bucket: string) {
    setEditingTask(null);
    setPrefillBucket(bucket);
    setModalOpen(true);
  }

  function openEditModal(task: Task) {
    setEditingTask(task);
    setModalOpen(true);
  }

  async function handleSave(data: {
    title: string;
    description: string;
    url: string;
    bucket: string;
    week_start: string;
    assignee: string;
  }) {
    if (editingTask) {
      const res = await fetch(`/api/tasks/${editingTask.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      setTasks((prev) =>
        prev.map((t) => (t.id === editingTask.id ? result.task : t))
      );
    } else {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      setTasks((prev) => [result.task, ...prev]);
    }
    setModalOpen(false);
  }

  async function handleLogout() {
    await fetch('/api/auth', { method: 'DELETE' });
    router.push('/login');
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg)' }}>
      {/* Header */}
      <header
        className="sticky top-0 z-10 px-5 md:px-8 py-4"
        style={{ background: 'var(--bg)', borderBottom: '1px solid var(--line)' }}
      >
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div>
            <p
              className="text-xs uppercase tracking-widest mb-0.5"
              style={{ color: 'var(--accent)' }}
            >
              Rubans D2C
            </p>
            <h1 className="font-display text-xl md:text-2xl" style={{ color: 'var(--ink)' }}>
              Task Tracker
            </h1>
          </div>
          <button
            onClick={handleLogout}
            className="text-xs px-3 py-1.5 rounded-md"
            style={{ color: 'var(--ink-soft)', border: '1px solid var(--line)' }}
          >
            Log out
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-5 md:px-8 py-6">
        {/* Week selector + progress */}
        <div className="flex flex-wrap items-center gap-3 mb-6">
          <select
            value={selectedWeek}
            onChange={(e) => setSelectedWeek(e.target.value)}
            className="text-sm rounded-md px-3 py-2"
            style={{ border: '1px solid var(--line)', background: 'var(--surface)' }}
          >
            {weekOptions.map((w) => (
              <option key={w} value={w}>
                {formatWeekLabel(w)}
                {w === currentWeekStart() ? ' (this week)' : ''}
                {w === nextWeekStart() ? ' (next week)' : ''}
              </option>
            ))}
          </select>

          <select
            value={bucketFilter}
            onChange={(e) => setBucketFilter(e.target.value)}
            className="text-sm rounded-md px-3 py-2"
            style={{ border: '1px solid var(--line)', background: 'var(--surface)' }}
          >
            <option value="all">All buckets</option>
            {BUCKETS.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2 ml-auto">
            <div
              className="w-32 h-2 rounded-full overflow-hidden"
              style={{ background: 'var(--line)' }}
            >
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${weekProgress}%`, background: 'var(--done)' }}
              />
            </div>
            <span className="text-sm" style={{ color: 'var(--ink-soft)' }}>
              {weekProgress}% done · {weekTasks.filter((t) => t.status === 'done').length}/
              {weekTasks.length}
            </span>
          </div>
        </div>

        {loading ? (
          <p className="text-sm" style={{ color: 'var(--ink-soft)' }}>
            Loading…
          </p>
        ) : (
          <div className="space-y-6">
            {(bucketFilter === 'all' ? BUCKETS : [bucketFilter]).map((bucket) => {
              const items = tasksByBucket[bucket] || [];
              return (
                <div
                  key={bucket}
                  className="rounded-lg overflow-hidden"
                  style={{ background: 'var(--surface)', border: '1px solid var(--line)' }}
                >
                  <div
                    className="flex items-center justify-between px-4 py-3"
                    style={{ borderBottom: '1px solid var(--line)' }}
                  >
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-semibold" style={{ color: 'var(--ink)' }}>
                        {bucket}
                      </h2>
                      <span
                        className="text-xs rounded-full px-2 py-0.5"
                        style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}
                      >
                        {items.length}
                      </span>
                    </div>
                    <button
                      onClick={() => openAddModal(bucket)}
                      className="text-xs px-2.5 py-1 rounded-md"
                      style={{ color: 'var(--accent)', border: '1px solid var(--accent-soft)' }}
                    >
                      + Add task
                    </button>
                  </div>

                  {items.length === 0 ? (
                    <p
                      className="text-sm px-4 py-4"
                      style={{ color: 'var(--ink-soft)' }}
                    >
                      No tasks yet for this week.
                    </p>
                  ) : (
                    <ul>
                      {items.map((task) => (
                        <li
                          key={task.id}
                          className="px-4 py-3 flex items-start gap-3 group"
                          style={{ borderTop: '1px solid var(--line)' }}
                        >
                          <button
                            onClick={() => toggleStatus(task)}
                            className="mt-0.5 shrink-0 w-5 h-5 rounded-full flex items-center justify-center transition-colors"
                            style={{
                              border: `1.5px solid ${task.status === 'done' ? 'var(--done)' : 'var(--line)'}`,
                              background: task.status === 'done' ? 'var(--done)' : 'transparent',
                            }}
                            aria-label="Toggle complete"
                          >
                            {task.status === 'done' && (
                              <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
                                <path
                                  d="M2 6l2.5 2.5L10 3"
                                  stroke="white"
                                  strokeWidth="1.8"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                              </svg>
                            )}
                          </button>

                          <div className="flex-1 min-w-0">
                            <p
                              className="text-sm cursor-pointer"
                              style={{
                                color: task.status === 'done' ? 'var(--ink-soft)' : 'var(--ink)',
                                textDecoration: task.status === 'done' ? 'line-through' : 'none',
                              }}
                              onClick={() => openEditModal(task)}
                            >
                              {task.title}
                            </p>
                            {task.description && (
                              <p
                                className="text-xs mt-0.5"
                                style={{ color: 'var(--ink-soft)' }}
                              >
                                {task.description}
                              </p>
                            )}
                            <div className="flex items-center gap-3 mt-1">
                              {task.url && (
                                <a
                                  href={task.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs underline"
                                  style={{ color: 'var(--accent)' }}
                                >
                                  Link
                                </a>
                              )}
                              {task.assignee && (
                                <span className="text-xs" style={{ color: 'var(--ink-soft)' }}>
                                  {task.assignee}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => openEditModal(task)}
                              className="text-xs px-2 py-1 rounded"
                              style={{ color: 'var(--ink-soft)' }}
                            >
                              Edit
                            </button>
                            <button
                              onClick={() => deleteTask(task.id)}
                              className="text-xs px-2 py-1 rounded"
                              style={{ color: 'var(--danger)' }}
                            >
                              Delete
                            </button>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      {modalOpen && (
        <TaskModal
          task={editingTask}
          defaultBucket={prefillBucket}
          defaultWeek={selectedWeek}
          onClose={() => setModalOpen(false)}
          onSave={handleSave}
        />
      )}
    </div>
  );
}
