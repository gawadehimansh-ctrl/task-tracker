'use client';

import { useState } from 'react';
import { BUCKETS } from '@/lib/db';
import { addWeeks, currentWeekStart, formatWeekLabel } from '@/lib/weeks';
import type { Task } from './Dashboard';

type Props = {
  task: Task | null;
  defaultBucket: string;
  defaultWeek: string;
  onClose: () => void;
  onSave: (data: {
    title: string;
    description: string;
    url: string;
    bucket: string;
    week_start: string;
    assignee: string;
  }) => Promise<void>;
};

export default function TaskModal({ task, defaultBucket, defaultWeek, onClose, onSave }: Props) {
  const [title, setTitle] = useState(task?.title || '');
  const [description, setDescription] = useState(task?.description || '');
  const [url, setUrl] = useState(task?.url || '');
  const [bucket, setBucket] = useState(task?.bucket || defaultBucket);
  const [weekStart, setWeekStart] = useState(task?.week_start || defaultWeek);
  const [assignee, setAssignee] = useState(task?.assignee || '');
  const [saving, setSaving] = useState(false);

  const weekOptions = (() => {
    const cur = currentWeekStart();
    const opts: string[] = [];
    for (let i = -8; i <= 4; i++) opts.push(addWeeks(cur, i));
    return opts;
  })();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    await onSave({ title: title.trim(), description, url, bucket, week_start: weekStart, assignee });
    setSaving(false);
  }

  return (
    <div
      className="fixed inset-0 z-20 flex items-center justify-center px-4"
      style={{ background: 'rgba(36,31,28,0.4)' }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-lg p-6 max-h-[90vh] overflow-y-auto"
        style={{ background: 'var(--surface)' }}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="font-display text-lg mb-4" style={{ color: 'var(--ink)' }}>
          {task ? 'Edit task' : 'New task'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--ink-soft)' }}>
              Title
            </label>
            <input
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-md px-3 py-2 text-sm"
              style={{ border: '1px solid var(--line)' }}
              placeholder="e.g. Launch Meta prospecting campaign for new SKUs"
              required
            />
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--ink-soft)' }}>
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-md px-3 py-2 text-sm"
              style={{ border: '1px solid var(--line)' }}
              rows={3}
              placeholder="Context, notes, or details"
            />
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--ink-soft)' }}>
              URL (optional)
            </label>
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full rounded-md px-3 py-2 text-sm"
              style={{ border: '1px solid var(--line)' }}
              placeholder="https://…"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--ink-soft)' }}>
                Bucket
              </label>
              <select
                value={bucket}
                onChange={(e) => setBucket(e.target.value)}
                className="w-full rounded-md px-3 py-2 text-sm"
                style={{ border: '1px solid var(--line)' }}
              >
                {BUCKETS.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--ink-soft)' }}>
                Week
              </label>
              <select
                value={weekStart}
                onChange={(e) => setWeekStart(e.target.value)}
                className="w-full rounded-md px-3 py-2 text-sm"
                style={{ border: '1px solid var(--line)' }}
              >
                {weekOptions.map((w) => (
                  <option key={w} value={w}>
                    {formatWeekLabel(w)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--ink-soft)' }}>
              Assignee (optional)
            </label>
            <input
              value={assignee}
              onChange={(e) => setAssignee(e.target.value)}
              className="w-full rounded-md px-3 py-2 text-sm"
              style={{ border: '1px solid var(--line)' }}
              placeholder="e.g. You, or a team member's name"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="text-sm px-3 py-2 rounded-md"
              style={{ color: 'var(--ink-soft)' }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || !title.trim()}
              className="text-sm px-4 py-2 rounded-md text-white disabled:opacity-50"
              style={{ background: 'var(--accent)' }}
            >
              {saving ? 'Saving…' : task ? 'Save changes' : 'Add task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
